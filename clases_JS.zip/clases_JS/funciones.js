var misBandas = [];

function limpiar(){
  let nombre = document.getElementById("nombre").value = "";
  let genero = document.getElementById("genero").value = "";
  let integrantes = document.getElementById("integrantes").value = "";
}

//función que fuardara la información de los campos para enviarla y ser almacenados en el objeto
function validarEnvio(){
  let nombre = document.getElementById("nombre").value;
  let genero = document.getElementById("genero").value;
  let integrantes = document.getElementById("integrantes").value;

  if(nombre != "" && genero != "" && integrantes != ""){
    guardarDatosEnObjeto(nombre,genero,integrantes);
    document.getElementById("nombre").value = "";
    document.getElementById("genero").value = "";
    document.getElementById("integrantes").value = "";
  }
  else{
    console.log("No se enviaron los datos a la función guardarDatosEnObjeto");
  }
}

function guardarDatosEnObjeto(nombre, genero, integrantes){
  console.log("Recibi los datos correctamente");
  console.log(nombre + " " + genero + " " + integrantes);

  var banda = new Bandas(nombre, genero, integrantes);
  misBandas.push(banda);
  console.log(misBandas);
  //creo una variable json
  var miJson = {};
  //a mi json ke asignaré lo que contiene mi arreglo misBandas
  miJson = JSON.stringify(misBandas);
  console.log(miJson);
}

function ejemploJoin(){
  var miArrayNombre = ["Antonio", "Enrique", "Santoveña", "Vazquez"];
  var junto = miArrayNombre.join("*");
  console.log(junto);
}
