function convertirJson(){
var jsonEjemplo = '{"Nombre": "America","Ciudad": "Mexico","Estadio": "Azteca","titulos": 12}';

if(jsonEjemplo != " "){
  var newCadena = JSON.parse(jsonEjemplo); //Convierte la cadena jsonEjemplo en Json

  console.log(newCadena);//Muestra por consola la cadena

}else{
  jsonEjemplo = " ";
}

document.getElementById('cadena').value = newCadena.Nombre + " " + newCadena.Ciudad + " " + newCadena.Estadio + " " + newCadena.titulos;

}

function limpiar(){
  document.getElementById('cadena').value = "";
}
