var personas = [];
let verPersonas = [];

function habilitar(){
  var nombre = document.getElementById('nombre').value;
  var edad = document.getElementById('edad').value;
  var correo = document.getElementById('correo').value;

  if(nombre === "" || edad === "" || correo === ""){
    document.getElementById('btnAgregar').disabled = true;
  }else{
    document.getElementById('btnAgregar').disabled = false;
  }




}


function validar(){
   var nombre = document.getElementById('nombre').value;
   var edad = document.getElementById('edad').value;
   var correo = document.getElementById('correo').value;
   //const correo2 = document.getElementById('correo').value;
   //var i = 0;
  console.log(nombre + edad + correo);//Imprimir nombre, edad y correo juntos


  if(nombre != "" && edad != "" && correo != ""){

    agregar(nombre,edad,correo);
  }



//Vaciar campos
document.getElementById('nombre').value = "";
document.getElementById('edad').value = "";
document.getElementById('correo').value = "";


}

function agregar(nombre, edad, correo){
  let personasR = new Personas(nombre,edad,correo);
  personas.push(personasR);
  //console.log(personas);
  mostrarRegistros();


}

function validaCorreo (){
  console.log("Inicia validación de correo");
  var correo = document.getElementById('correo').value;

  for(var i = 0; i<personas.length; i++){
    if(correo == personas[i].correo){
      console.log("El correo es identico al siguiente: ");
      console.log( personas[i]);
    }else{
      agregar(nombre,edad,correo);
    }
  }

}

function mostrarRegistros(){

  console.log(personas);
  let tablaBody = "";
  let idbtn = "";

  for(var i= 0; i<personas.length; i++){
    //var tr = document.createElement('BUTTON');
    //var td = document.createElement('td');
    idbtn = i;

     tablaBody += `
      <tr>
        <td>${i + 1}</td>
        <td>${personas[i].nombre}</td>
        <td>${personas[i].edad}</td>
        <td>${personas[i].correo}</td>
        <td><button id="${i}" onclick="eliminar(${i});" class="botonesTabla">Eliminar</button></td>
        <td><button id="${i}" onclick="iniciaEditar(${i});" class="botonesTabla">Editar</button></td>
      </tr>
    `;
  }

  document.getElementById('tbody').innerHTML = tablaBody;




}

function eliminar(idbtn){

  //console.log(idbtn);

  //delete te permite eliminar el contenido del elemento,
  //aunque el registro queda en blanco
  delete personas[idbtn];
  //console.log(personas);

  //Splice elimina el registro el blanco que provocó el delete
  personas.splice(idbtn, 1); // 1 es la cantidad de elemento a eliminar

  //Corroborar por consola que se eliminó por completo el registro
  //console.log( personas );

  //ejecutamos de nuevo el método mostrar para actualizar la tabla
  mostrarRegistros();

}

function iniciaEditar(idbtn){

  const editSection = document.getElementById('editSection');
  editSection.innerHTML = `
    <button id="${idbtn}" onclick="terminaEditar(${idbtn});" class="botonEditar">Confirmar edición</button>
  `;

  console.log("***Proceso de editar ***");
  console.log(personas[idbtn]);

  document.getElementById('nombre').value = personas[idbtn].nombre;
  document.getElementById('edad').value = personas[idbtn].edad;
  document.getElementById('correo').value = personas[idbtn].correo;




}


function terminaEditar(idbtn){

  personas[idbtn].nombre = document.getElementById('nombre').value;
  personas[idbtn].edad = document.getElementById('edad').value;
  personas[idbtn].correo = document.getElementById('correo').value;
  editSection.innerHTML = `
  `;

  //Vaciar campos
  document.getElementById('nombre').value = "";
  document.getElementById('edad').value = "";
  document.getElementById('correo').value = "";

  mostrarRegistros();
}


function limpiar(){
  var nombre = document.getElementById('nombre').value = "";
  var edad = document.getElementById('edad').value = "";
  var correo = document.getElementById('correo').value = "";
}
