class Alumnos{
  constructor(nombre, promedio){
    this.nombre = nombre;
    this.promedio = promedio;
  }
}
