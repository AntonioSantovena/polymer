//customEvents



const body = document.querySelector('body');
const div = document.createElement('div');

div.innerText = 'Estoy escuchando al evento some-event';
div.addEventListener('some-event', event =>{
  div.innerHTML = `
  <div style="background: green; color: white">
    ${event.datail.data}
  </div>
  `;
});
body.appendChild(div);


setTimeOut( =>{
  div.dispatchEvent(new CustomEvent('some-event',{
    bubbles: true,
    detail:{
      data: 'evento creado'
    }
  }));

}, 5000);
