function conversion()
{
var pesos = document.getElementById("pesos").value;
var tCambio = document.getElementById("tCambio").value;

var dolares = pesos * tCambio;

document.getElementById('dolares').value = "$" + dolares;

console.log("Dolares: $" + dolares);

console.log("Hola Mundo");
}

function limpiar(){
  document.getElementById('pesos').value = "";
  document.getElementById('tCambio').value = "";
  document.getElementById('dolares').value = "";

}
