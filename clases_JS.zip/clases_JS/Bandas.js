class Bandas{
   constructor(nombre, genero, integrantes){
     this.nombre = nombre;
     this.genero = genero;
     this.integrantes = integrantes;
   }

}
