class Bandas{
  constructor(id, nombre, genero, integrantes){
    this.id = id;
    this.nombre = nombre;
    this.genero = genero;
    this.integrantes = integrantes;
  }
}
