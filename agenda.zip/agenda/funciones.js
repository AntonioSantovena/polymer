var personas = [];

function validar(){
   var nombre = document.getElementById('nombre').value;
   var edad = document.getElementById('edad').value;
   var correo = document.getElementById('correo').value;
  console.log(nombre + edad + correo);//Imprimir nombre, edad y correo juntos

   //var arrayContact = (nombre, edad, correo);
   //console.log(arrayContact);
   //console.log(arrayContact[1]); //Verifico que el array contenga los tres elementos separados



/* codigo for generar tabla
   var table = document.createElement("table");
   document.body.appendChild(table);
   table.id="table10";
   var table = document.getElementById('table10');
   for(i = 0; i<=arrayContact.length; i++){
     table.innerHTML = `
     <tr>
     <td>${nombre}</td>
     <td>${edad}</td>
     <td>${correo}</td>
     </tr>
     `;

   };
*/

agregar(nombre,edad,correo);



}

function agregar(nombre, edad, correo){
  let personasR = new Personas(nombre,edad,correo);
  personas.push(personasR);
  console.log(personas);

}



function limpiar(){
  var nombre = document.getElementById('nombre').value = "";
  var edad = document.getElementById('edad').value = "";
  var correo = document.getElementById('correo').value = "";
}
