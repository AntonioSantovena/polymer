function prueba1(){
var prueba;
var result = prueba * 10;
console.log(result);
}
