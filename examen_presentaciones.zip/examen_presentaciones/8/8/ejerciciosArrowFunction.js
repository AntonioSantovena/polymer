//Arow function
    //funcion normal
    var funcionTradicional = function(valor) {
      return valor;
    }
    console.log(funcionTradicional("Soy function Tradicional"));
  
    //funcion flecha
    var funcionFlecha = valor => {
     return valor;
    };
    console.log(funcionFlecha("Soy function flecha"));


//sintaxis basica
    //funcion un parametro basica
    var funcionUnParametro = parametro => {
         return parametro * 2;
    }
    console.log(funcionUnParametro(10));

    //funcion mas de un parametro basica
    var funcionMasDeUnParametro = (parametro1 , parametro2) => {
         return parametro1 + parametro2;
    }
    console.log(funcionMasDeUnParametro(10, 20));

    //funcion sin parametros optimizada
    var funcionSinParametro = () => {
         return 50;
    }
    console.log(funcionSinParametro());


//sintaxis optimizada
    //funcion flecha un parametro optimizada
    var funcionUnParametro = parametro => parametro * 2;
    console.log("Un parametro optimizada: "+funcionUnParametro(10));
    
    //funcion flecha mas de unparametro optimizada
    var funcionMasDeUnParametro = (parametro1 , parametro2) => parametro1 + parametro2;
    console.log("Mas de un parametro Optimizada: "+funcionMasDeUnParametro(10, 20));

    //funcion flecha sin parametros optimizada
    var funcionSinParametro = () => 50;
    console.log("Sin parametros optimizada: "+funcionSinParametro());

//comparacion
    const nombres = ['Carlos','Alejandro','Ivan','JoseLuis'];
    //funcion normal
    var fnormal= nombres.map(function(nombre){
        return `${nombre} tiene ${nombre.length} caracteres `;
      });
    console.log(fnormal);

    //funcion flecha
    let flecha1 = nombres.map ( nombre =>  `${nombre} tiene ${nombre.length} caracteres`);
    console.log(flecha1);

    //Funcion flecha optimizada
    let flecha2 = nombres.map ( nombre =>  `${nombre} tiene ${nombre.length} caracteres`);
    console.log(flecha2);
