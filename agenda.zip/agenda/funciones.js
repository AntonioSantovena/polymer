function agregar(){
   var nombre = document.getElementById('nombre').value;
   var edad = document.getElementById('edad').value;
   var correo = document.getElementById('correo').value;
  console.log(nombre + edad + correo);//Imprimir nombre, edad y correo juntos

   var arrayContact = (nombre, edad, correo);
   console.log(arrayContact);
   console.log(arrayContact[1]); //Verifico que el array contenga los tres elementos separados

   var table = document.createElement("table");
   document.body.appendChild(table);
   table.id="table10";
   var table = document.getElementById('table10');
   for(i = 0; i<=arrayContact.length; i++){
     table.innerHTML = `
     <tr>
     <td>${nombre}</td>
     <td>${edad}</td>
     <td>${correo}</td>
     </tr>
     `;

     //var fila = document.createElement("tr");
     //table.appendChild(fila);

   };





}



function limpiar(){
  var nombre = document.getElementById('nombre').value = "";
  var edad = document.getElementById('edad').value = "";
  var correo = document.getElementById('correo').value = "";
}
