const container = document.getElementById('personaje');
const descripcionPersonaje = document.getElementById('descripcionPersonaje');

console.log(container);

function onClickButton(id) {
  console.log(id);
  obtenerPersonaje(id)
    .then(function (response) {
      if (response.gender === 'n/a') {
        response.gender = 'no-gender';
      }
      container.innerText = JSON.stringify(response, null, 4);
      container.innerHTML = `
        <h3 class=${response.gender} align="center">Nombre: ${response.name}</h3>

        <h3 class=${response.gender} align="center">Altura: ${response.height}</h3>
        <h3 class=${response.gender} align="center">Peso: ${response.mass}</h3>
        <h3 class=${response.gender} align="center">Color cabello: ${response.hair_color}</h3>
        <h3 class=${response.gender} align="center">Color de piel: ${response.skin_color}</h3>
        <h3 class=${response.gender} align="center">Color de ojos: ${response.eye_color}</h3>
        <h3 class=${response.gender} align="center">Año de nacimiento: ${response.birth_year}</h3>

      `;
    })
    .then(function (response){
      if(id == 1){
      console.log(id);
      descripcionPersonaje.innerHTML = `
        <img src="luke.png">

      `;

      
    }



    })
    .then(function (response){
      if(id == 2){
      console.log(id);
      descripcionPersonaje.innerHTML = `
        <img src="c3po.jpg">

      `;
    }



    })
    .then(function (response){
      if(id == 3){
      console.log(id);
      descripcionPersonaje.innerHTML = `
        <img src="r2d22.jfif">

      `;
    }



    })
    .then(function (response){
      if(id == 5){
      console.log(id);
      descripcionPersonaje.innerHTML = `
        <img src="leia.jpg" align="center">

      `;
    }



    });

}
