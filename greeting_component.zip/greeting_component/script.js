/* If you're feeling fancy you can add interactivity 
    to your site with Javascript */

// prints "hi" in the browser's dev tools console
//console.log('hi');

// CLase
//HTMLElement

// crea un custom element
//customElements


// shadow dom 
// encapsula css y html
//<mi-webcomponent>
//  |
//  --shadowRooot --> <div> <img></img></div> 
//</mi-webcomponent>
customElements.define('my-web-component-greeting', class MyWebComponentGreeting extends HTMLElement {
  // propiedades/attributos
  // greeting
  get greeting() {
    return this.getAttribute('greeting');
  }
  
  set greeting(greeting) {
    if (greeting) {
      this.setAttribute('greeting', greeting);
    } else {
      this.removeAttribute('greeting');
    } 
  }
  // greeting color
  get greetingColor() {
    return this.getAttribute('greetingColor');
  }
  
  set greetingColor(greetingColor) {
    if (greetingColor) {
      this.setAttribute('greetingColor', greetingColor);
    } else {
      this.removeAttribute('greetingColor');
    } 
  } 
  
  static get observedAttributes() {
    return ['greetingcolor', 'greeting'];
  }
  
  // metodos
  constructor() {
    super();
    const shadowRoot = this.attachShadow({ mode: 'open' });
    shadowRoot.innerHTML = this.getTemplate();
  } 
  
  attributeChangedCallback(name, oldValue, newValue) {
    debugger;
    this.shadowRoot.innerHTML = this.getTemplate(); 

  }
  
  getTemplate() {
   return `
    <style>
      .blue {
        color: blue;
      }
      .red {
        color: red;
      }
    </style>
    <div id="container">
      <p class="${this.greetingColor}">HOLA ${this.greeting}</p>
    </div>
   `;
  }
   
});
