//Clase HTMLElements brinda los atributos a customElements para definir etiquetas
//shadow dom encapsula CSS y html

customElements.define('my-webcomponent-login', class MiWebComponent extends HTMLElement {
    //propiedades
    get greeting(){
      return this.getAttribute('greeting');
    }
    set greeting(greeting){
      if(greeting != undefined){
        this.setAttribute('greeting', greeting);
      }else{
        this.removeAttribute('greeting');
      }
    }

    //greetingColor
    get greetingColor(){
      return this.getAttribute('greetingColor');
    }
    set greetingColor(greetingColor){
      if(greetingColor != undefined){
        this.setAttribute('greetingColor', greetingColor);
      }else{
        this.removeAttribute('greetingColor');
      }
    }

    static get observedAttributes(){
      return ['greeting', 'greetingcolor' ];
    }




    constructor(){
      super();
      //Siempre debe estar en mode: open para acceder a sus css, además de ser buena practica
    const shadowRoot = this.attachShadow({mode: 'open'});
    shadowRoot.innerHTML = this.getTemplate();
    }

    connectedCallback(){
      const button = this.shadowRoot.getElementById('button');
      button.addEventListener('click', this.inputValidator.bind(this));
    }

    attributeChangedCallback(name, oldValue, newValue){
      //debugger;
      this.shadowRoot.innerHTML = this.getTemplate();
    }

    getTemplate(){
      return `
        <style>
        .blue{
          color: blue;

        }
        .red{
          color: red;
        }
        </style>
        <!--<div><p class="blue">Hola ${this.greeting}</p></div>-->
        <slot></slot>
        <div><p class="${this.greetingColor}">Hola ${this.greeting}</p></div>
        <slot name="greeting-text"><h1>some greeting text</h1></slot>
        <label>Ingresa tu contraseña</label>
        <input id="input" type="password"></input><button id="button">enviar</butoon>

      `;
    }

    inputValidator(){
      const input = this.shadowRoot.getElementById('input');
      console.log(input.value);
      let isValid = /^[a-z]{8}$/.test(input.value);
      console.log(isValid);
      if(isValid){
        this.fire('login-success', {
          code: '200',
          message: 'autenticación exitoda'
        });
      }else{
        this.fire('login-error', {
          code: '404',
          message: 'Autenticación erronea'
        });
      }
    }

    fire(eventName, data){
      debugger;
      this.dispatchEvent(new CustomEvent(eventName, {
        bubbles: true,
        composed: true,
        detail: data
      }))
    }
});
