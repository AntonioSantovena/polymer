/*
function hola(){
  var cadena = document.getElementById("cadena").value;
  console.log(cadena);
  var arreglo = [];
  arreglo.push(cadena);
  console.log(arreglo[1]);
}
*/

function dividirCadena(cadenaADividir,separador) {
  var cadena = document.getElementById("cadena").value;
  var corrida = document.getElementById("corrimiento").value;
  let result = cifrar(cadena, corrida);
  document.getElementById('cifrado').value = result;
}

function cifrar(cadena, corrida){
  let dato = "";
  let arrayCadena = cadena.split("");
  let nCorrida = parseInt(corrida);
  console.log(arrayCadena);

  arrayCadena.forEach(element =>{

    if(element != ""){

      var ascii= element.charCodeAt(0);
      console.log(ascii);
      var let1= String.fromCharCode(ascii + nCorrida);

      dato = dato + let1;

      //console.log(let1);
      //var let2= ascii + nCorrida;
      //console.log(let2);
      //dato = dato + let2;

    }else{
      dato = dato + " ";
    }

  }); return dato;
//document.getElementById('cifrado').value = dato;
}

function limpiar (){
  document.getElementById('cadena').value = "";
  document.getElementById('corrimiento').value = "";
  document.getElementById('cifrado').value = "";
}



function habilitar(){
  let cadena = document.getElementById('cadena');
  let corrida = document.getElementById('corrimiento');


  if(cadena != "" && corrida != ""){
    document.getElementById('btn1').disabled = false;
  }else{
    document.getElementById('btn1').disabled = true;
  }
}
