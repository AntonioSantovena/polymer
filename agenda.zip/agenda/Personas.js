function Personas(){

}

function Personas(nombre, edad, correo){
    this.nombre = nombre;
    this.edad = edad;
    this.correo = correo;

  }


/*
  Personas.prototype.setNombre = function(nombre){
    this.nombre = nombre;
  }

  Personas.prototye.getEdad = function(){
    return this.edad;
  }

  Personas.prototype.setEdad = function(edad){
    this.nombre = edad;
  }

  Personas.prototye.getCorreo = function(){
    return this.correo;
  }

  Personas.prototype.setCorreo = function(correo){
    this.nombre = correo;
  }

  Personas.prototye.getNombre = function(){
    return this.nombre;
  }
*/
