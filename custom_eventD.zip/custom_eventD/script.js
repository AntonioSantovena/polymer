/* If you're feeling fancy you can add interactivity 
    to your site with Javascript */

// prints "hi" in the browser's dev tools console
//console.log('hi');

// CLase
//HTMLElement

// crea un custom element
//customElements


// shadow dom 
// encapsula css y html
//<mi-webcomponent>
//  |
//  --shadowRooot --> <div> <img></img></div> 
//</mi-webcomponent>
customElements.define('my-web-component-login', class MyWebComponentLogin extends HTMLElement {
  // propiedades/attributos
  // greeting
  get greeting() {
    return this.getAttribute('greeting');
  }
  
  set greeting(greeting) {
    if (greeting) {
      this.setAttribute('greeting', greeting);
    } else {
      this.removeAttribute('greeting');
    } 
  }
  // greeting color
  get greetingColor() {
    return this.getAttribute('greetingColor');
  }
  
  set greetingColor(greetingColor) {
    if (greetingColor) {
      this.setAttribute('greetingColor', greetingColor);
    } else {
      this.removeAttribute('greetingColor');
    } 
  } 
  
  static get observedAttributes() {
    return ['greetingcolor', 'greeting'];
  }
  
  // metodos
  constructor() {
    super();
    const shadowRoot = this.attachShadow({ mode: 'open' });
    shadowRoot.innerHTML = this.getTemplate();
  } 
  
  connectedCallback() {
    const button = this.shadowRoot.getElementById('button');
    button.addEventListener('click', this.inputValidator.bind(this));
  }
  
  attributeChangedCallback(name, oldValue, newValue) {
    this.shadowRoot.innerHTML = this.getTemplate(); 

  }
  
  // slot
  
  getTemplate() {
   return `
    <style>
      .blue {
        color: blue;
      }
      .red {
        color: red;
      }
    </style>
    <div id="container">
      <p class="${this.greetingColor}">HOLA ${this.greeting}</p>
    </div>
    <slot name="greeting-text">
      some greeting text must be here.
    </slot>
    <label>Ingresa tu contraseña:</label>
    <input id="input" type="password"/><button id="button">enviar</button>
   `;
  }
  
  inputValidator() {
    const input = this.shadowRoot.getElementById('input');
    console.log(input.value);
    let isValid = /^[a-z]{8}$/.test(input.value);
    console.log(isValid);
    if (isValid) {
      this.fire('login-success', {
       code: '200',
       message: 'autenticacion exitosa'
      });
    } else {
      this.fire('login-error', {
       code: '404',
       message: 'autenticacion errone verifique su contraseña'
      });
    }
  }
  
  fire(eventName, data) {
    this.dispatchEvent(new CustomEvent(eventName, {
      bubbles: true,
      composed: true,
      detail: data
    }));
  }
   
});
